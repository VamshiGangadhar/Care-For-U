import { CssBaseline } from '@mui/material'
import React from 'react'

const PateintDetails = () => {
  return (
    <CssBaseline>
        
    </CssBaseline>
  )
}

export default PateintDetails